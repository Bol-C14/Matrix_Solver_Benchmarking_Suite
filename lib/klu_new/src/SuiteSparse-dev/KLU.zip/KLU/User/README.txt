This directory contains a sample user-ordering function, klu_cholmod.
Its use (and the use of CHOLMOD) is optional.

Timothy A. Davis, http://www.suitesparse.com

//------------------------------------------------------------------------------
// KLU/Tcov/klultest.c: int64_t version of klutest
//------------------------------------------------------------------------------

// KLU, Copyright (c) 2004-2022, University of Florida.  All Rights Reserved.
// Authors: Timothy A. Davis and Ekanathan Palamadai.
// SPDX-License-Identifier: LGPL-2.1+

//------------------------------------------------------------------------------


#define DLONG
#include "klutest.c"

